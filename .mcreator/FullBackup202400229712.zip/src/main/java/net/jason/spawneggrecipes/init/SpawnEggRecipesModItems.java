
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.jason.spawneggrecipes.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;

import net.minecraft.world.item.Item;

import net.jason.spawneggrecipes.item.TotemOfInapproachableItem;
import net.jason.spawneggrecipes.SpawnEggRecipesMod;

public class SpawnEggRecipesModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(SpawnEggRecipesMod.MODID);
	public static final DeferredHolder<Item, Item> TOTEM_OF_INAPPROACHABLE = REGISTRY.register("totem_of_inapproachable", TotemOfInapproachableItem::new);
	public static final DeferredHolder<Item, Item> BOSS_SPAWN_EGG = REGISTRY.register("boss_spawn_egg", () -> new DeferredSpawnEggItem(SpawnEggRecipesModEntities.BOSS, -1, -1, new Item.Properties()));
	// Start of user code block custom items
	// End of user code block custom items
}
